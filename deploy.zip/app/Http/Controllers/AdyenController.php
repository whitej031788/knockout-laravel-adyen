<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class AdyenController extends Controller
{
  public function __construct() {
    $this->adyenClient = new \Adyen\Client();
    $this->adyenClient->setXApiKey('AQEwhmfxLIzNbxNGw0m/n3Q5qf3VYopABJZrXHxTyEyujXLnN3P8LZwpAybFGzQ5dnT1EMFdWw2+5HzctViMSCJMYAc=-ZVuvWaNaFv5m/BktXaTMLvgclIBOr0TecHuSSdQeI5A=-k3a4zKNGsyqD9WJx');
    $this->adyenClient->setEnvironment(\Adyen\Environment::TEST);
  }

  public function getPaymentMethods(Request $request) {
    $checkoutService = new \Adyen\Service\Checkout($this->adyenClient);

    $validatedData = $request->validate([
        'merchantAccount' => 'required',
        'countryCode' => 'required',
        'channel' => 'required'
    ]);

    $params = array(
      "merchantAccount" => $request->merchantAccount,
      "countryCode" => $request->countryCode,
      "channel" => $request->channel,
      'shopperReference' => $request->shopperReference
    );

    if ($request->has("amount")) {
      $params['amount'] = $request->amount;
    }

    $result = $this->makeAdyenRequest("paymentMethods", $params, false, $checkoutService);

    return response()->json($result);
  }

  public function makePaymentSimple(Request $request) {
    $checkoutService = new \Adyen\Service\Checkout($this->adyenClient);

    $paymentMethod = $request->payData['paymentMethod'];

    $cacheKeyRedirect = "http://localhost:8000/normal-redirect/" . $request->shopperReference . "-" . $request->reference;

    $params = array(
      "amount" => $request->amount,
      "reference" => $request->reference,
      "countryCode" => $request->countryCode,
      "paymentMethod" => $paymentMethod,
      "channel" => $request->channel,
      "returnUrl" => $cacheKeyRedirect,
      "merchantAccount" => $request->merchantAccount,
      "shopperReference" => $request->shopperReference,
      "billingAddress" => $this->fakeAddressArray(),
      "deliveryAddress" => $this->fakeAddressArray(),
      "merchantOrderReference" => "merchantOrderReference2",
      "metadata" => array(
        "test" => "test"
      ),
      "additionalData" => array(
        "RequestedTestAcquirerResponseCode" => 6
      ),
      // "splits" => array (
      //   array (
      //     'amount' => array (
      //       'value' => 150100,
      //     ),
      //     'type' => 'MarketPlace',
      //     'account' => '8815941267450207',
      //     'reference' => '6124145',
      //     'description' => 'Porcelain Doll: Eliza (20cm)',
      //   ),
      //   array (
      //     'amount' => array (
      //       'value' => 200,
      //     ),
      //     'type' => 'Commission',
      //     'reference' => '6124146',
      //   ),
      // )
    );

    if (array_key_exists('storePaymentMethod', $request->payData)) {
      $params['storePaymentMethod'] = $request->payData['storePaymentMethod'];
    }

    if ($request->has("recurringProcessingModel")) {
      $params['recurringProcessingModel'] = $request->recurringProcessingModel;
    }

    if (isset($paymentMethod['type']) && strpos($paymentMethod['type'], 'klarna') !== false) {
      $this->addKlarnaData($params);
    }

    // Add fake Apple Pay Stuff
    //if (isset($paymentMethod['type']) && strpos($paymentMethod['type'], 'applepay') !== false) {
    //  $this->addKlarnaData($params);
    //}

    $result = $this->makeAdyenRequest("payments", $params, false, $checkoutService);
    if (array_key_exists("channel", $params) && strtolower($params["channel"]) != "web") {
      if ($result['resultCode'] == 'RedirectShopper') {
        $cache = Cache::forever($request->shopperReference . '-' . $request->reference, $result['paymentData']);
        $result = $result['action'];
      }
    } else {
      if ($result['response']['resultCode'] == 'RedirectShopper') {
        $cache = Cache::forever($request->shopperReference . '-' . $request->reference, $result['response']['paymentData']);
      }
    }

    $output = new \Symfony\Component\Console\Output\ConsoleOutput();
    $output->writeln(json_encode($result));

    return response()->json($result);
  }

  public function makePayment3DS2(Request $request) {
    $checkoutService = new \Adyen\Service\Checkout($this->adyenClient);

    $paymentMethod = $request->payData['paymentMethod'];

    if ($request->populateFakeAddress) {
      $billingAddress = $this->fakeAddressArray();
    } else {
      $billingAddress = $request->payData['billingAddress'];
    }
    $browserInfo = $request->payData['browserInfo'];

    $cacheKeyRedirect = "http://localhost:8000/threeds-redirect/" . $request->shopperReference . "-" . $request->reference;

    $params = array(
      "amount" => $request->amount,
      "paymentMethod" => $paymentMethod,
      "reference" => $request->reference,
      "merchantAccount" => $request->merchantAccount,
      "shopperReference" => $request->shopperReference,
      // "additionalData" => array(
      //   "allow3DS2" => true
      // ),
      "shopperEmail" => 'jamie.white@adyen.com',
      "returnUrl" => $cacheKeyRedirect,
      "countryCode" => $request->countryCode,
      "channel" => $request->channel,
      "shopperInteraction" => "Ecommerce",
      "recurringProcessingModel" => "CardOnFile",
      "origin" => $request->origin,
      "shopperIP" => $_SERVER['REMOTE_ADDR'],
      "billingAddress" => $billingAddress,
      "browserInfo" => $browserInfo,
      "threeDSAuthenticationOnly" => $request->threeDSAuthenticationOnly
    );

    if (array_key_exists('storePaymentMethod', $request->payData)) {
      $params['storePaymentMethod'] = $request->payData['storePaymentMethod'];
    }

    if ($request->has("recurringProcessingModel")) {
      $params['recurringProcessingModel'] = $request->recurringProcessingModel;
    }

    $result = $this->makeAdyenRequest("payments", $params, false, $checkoutService);

    if ($result['response']['resultCode'] == 'RedirectShopper') {
      $cache = Cache::forever($request->shopperReference . '-' . $request->reference, $result['response']['paymentData']);
    }
    // Check if further action is needed.
    return response()->json($result);
  }

  public function paymentDetails(Request $request) {
    $checkoutService = new \Adyen\Service\Checkout($this->adyenClient);

    $params = $request->data;
    // Data object passed from onAdditionalDetails event of the front end parsed from JSON to an array

    $result = $this->makeAdyenRequest("paymentsDetails", $params, false, $checkoutService);

    return response()->json($result);
  }

  public function capturePayment(Request $request) {
    $modificationService = new \Adyen\Service\Modification($this->adyenClient);

    $params = $request->all();
    // Data object passed from onAdditionalDetails event of the front end parsed from JSON to an array

    $result = $this->makeAdyenRequest("capture", $params, false, $modificationService);

    return response()->json($result);
  }

  // DEPRECATED
  public function signHppHmac(Request $request) {
    //JSON-ify the data for the POST
    $pairs = $request->all();
    // Test Klarna
    $pairs["openinvoicedata.numberOfLines"] = "2";
    $pairs["openinvoicedata.line1.numberOfItems"] = "1";
    $pairs["openinvoicedata.line1.itemAmount"] = "3500";
    $pairs["openinvoicedata.line1.currencyCode"] = "GBP";
    $pairs["openinvoicedata.line1.itemVatAmount"] = "665";
    $pairs["openinvoicedata.line1.itemVatPercentage"] = "1900";
    $pairs["openinvoicedata.line1.vatCategory"] = "High";
    $pairs["openinvoicedata.line1.description"] = "Description 1";
    $pairs["openinvoicedata.line2.numberOfItems"] = "1";
    $pairs["openinvoicedata.line2.itemAmount"] = "2100";
    $pairs["openinvoicedata.line2.currencyCode"] = "GBP";
    $pairs["openinvoicedata.line2.itemVatAmount"] = "399";
    $pairs["openinvoicedata.line2.itemVatPercentage"] = "1900";
    $pairs["openinvoicedata.line2.vatCategory"] = "Low";
    $pairs["openinvoicedata.line2.description"] = "Description 2";

    var_dump($pairs);

    $HMAC_KEY = "70612EFE64ADF31F3468331815ADDE07FD5A31CF09E54EE50845C1D28ECA980D";
    $escapedPairs = array();

    ksort($pairs, SORT_STRING);

    foreach ($pairs as $key => $value) {
      $escapedPairs[$key] = str_replace(':','\\:', str_replace('\\', '\\\\', $value));
    }

    $signingString = implode(":", array_merge(array_keys($escapedPairs), array_values($escapedPairs)));

    $binaryHmacKey = pack("H*" , $HMAC_KEY);

    $binaryHmac = hash_hmac('sha256', $signingString, $binaryHmacKey, true);

    $signature = base64_encode($binaryHmac);

    return response()->json($signature);
  }

  public function threeDSRedirect(Request $request, $payRef) {
    $value = Cache::store('file')->get($payRef);
    $response = $this->redirPayDet($value, ['MD' => $request->MD, 'PaRes' => $request->PaRes]);

    return view('redirect-page', ['serverObject' => json_encode($response)]);
  }

  public function normalRedirect($payRef) {
    $value = Cache::store('file')->get($payRef);
    $input = Input::all();
    $response = $this->redirPayDet($value, $input);

    return view('redirect-page', ['serverObject' => json_encode($response)]);
  }

  public function classicPayment(Request $request) {
    $url = 'https://pal-test.adyen.com/pal/servlet/Payment/v51/authorise';

    $params = array(
      'reference' => '2378rt3gf4b3',
      'merchantAccount' => 'JamieAdyenTestECOM',
      'amount' => array(
        'value' => 15000,
        'currency' => 'USD'
      ),
      'additionalData' => array(
        'card.encrypted.json' => $request->encData
      )
    );

    $result = $this->makeAdyenRequest($url, $params, true, false);

    return response()->json($result);
  }

  public function payGiftCard(Request $request) {
    $url = 'https://pal-test.adyen.com/pal/servlet/Payment/v51/authorise';

    $params = array(
      'reference' => $request->reference,
      'merchantAccount' => $request->merchantAccount,
      'selectedBrand' => $request->selectedBrand,
      'amount' => $request->amount,
      'card' => $request->card
    );

    $result = $this->makeAdyenRequest($url, $params, true, false);

    return response()->json($result);
  }

  public function getApplePaySession(Request $request) {
    $theUrl = $request->sessionUrl;
    $ngrok = "ec2-3-10-207-85.eu-west-2.compute.amazonaws.com";

    $fields_string = json_encode(array(
      'merchantIdentifier' => "merchant.com.adyen.JamieAdyenTestECOM.test",
      'displayName' => "Jamie's ApplePay Store",
      'initiative' => "web",
      'initiativeContext' => $ngrok
    ));
    //open connection
    $ch = curl_init();
    //set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_URL, $theUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json'
    ));
    curl_setopt($ch, CURLOPT_SSLCERT, Storage::path('apple-pay-cert.pem')); // physical path to .pem file
    //curl_setopt($ch, CURLOPT_SSLKEY, Storage::path('apple-pay-cert.pem')); // physical path to .pem file
    //execute post
    $result = json_decode(curl_exec($ch));

    Log::info(json_encode($result));

    return response()->json($result);
  }

  private function fakeAddressArray() {
    return [
      "city" => "London",
      "country" => "GB",
      "houseNumberOrName" => "165",
      "postalCode" => "EC1V 9ND",
      "street" => "Old Street"
    ];
  }

  private function fakeShopperName() {
    return [
      'firstName' => 'Jamie',
      'gender' => 'male',
      'lastName' => 'White'
    ];
  }

  private function fakeKlarnaLineItems($numItems) {
    $retArr = array();
    for ($x = 0; $x < $numItems; $x++) {
      $tmpArr = array(
        'quantity' => 1,
        'amountExcludingTax' => '500',
        'taxPercentage' => '2000',
        'description' => 'Test Klarna',
        'id' => $x + 100,
        'taxAmount' => (500 * 0.2),
        'amountIncludingTax' => '600'
      );
      array_push($retArr, $tmpArr);
    }
    return $retArr;
  }

  private function redirPayDet($paymentData, $details) {
    $checkoutService = new \Adyen\Service\Checkout($this->adyenClient);

    $params = array(
      'paymentData' => $paymentData,
      'details' => $details
    );

    $result = $this->makeAdyenRequest("paymentsDetails", $params, false, $checkoutService);

    return $result;
  }

  private function addKlarnaData(&$params) {
    $params['shopperLocale'] = 'en_US';
    $params['shopperEmail'] = 'jamie.white+red@adyen.com';
    $params['billingAddress'] = $this->fakeAddressArray();
    $params['lineItems'] = $this->fakeKlarnaLineItems(2);
    $params['shopperName'] = $this->fakeShopperName();
  }

  private function makeAdyenRequest($methodOrUrl, $params, $isClassic, $service) {
    $output = new \Symfony\Component\Console\Output\ConsoleOutput();
    $output->writeln(json_encode($params));
    if (!$isClassic) {
      try {
        $result = $service->$methodOrUrl($params);
        $output->writeln(json_encode($result));
      } catch (Exception $e) {
        $output->writeln(json_encode($e));
      }
    } else {
      //JSON-ify the data for the POST
      $fields_string = json_encode($params);
      //Basic auth user
      $username = "ws_363464@Company.JamieAdyenTest";
      $password = "}+5k?72wIZSQ6n7Xks^t^3S--";

      //open connection
      $ch = curl_init();
      //set the url, number of POST vars, POST data
      curl_setopt($ch, CURLOPT_URL, $methodOrUrl);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
      curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json'
      ));

      //execute post
      $result = json_decode(curl_exec($ch));
    }

    if (array_key_exists("channel", $params) && strtolower($params["channel"]) != "web") {
      // For app channels, just return raw result data
      return $result;
    } else {
      //  For web channel, return the helpful POSTMAN style data
      return array(
        "method" => $methodOrUrl,
        "request" => $params,
        "response" => $result,
      );
    }
  }
}

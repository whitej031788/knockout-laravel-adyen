@extends('layouts.main')

@section('content')
  <div class="row see-through mild-opacity mt-3">
    <div class="col-md-6 offset-md-3">
      <h3 class="text-center">POS Terminal API</h3>
    </div>
  </div>
@endsection

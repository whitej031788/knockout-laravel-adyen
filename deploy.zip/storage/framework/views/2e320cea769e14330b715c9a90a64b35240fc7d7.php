<?php $__env->startSection('content'); ?>
  <script>
    bladeJsonObj = <?php echo $serverObject; ?>;
  </script>
  <div class="row see-through mild-opacity mt-3">
    <div class="col-md-6 offset-md-3">
      <h3 class="text-center">Adyen Redirect Result</h3>
      <p>Many Adyen payment methods redirect the shopper away, and then eventually redirect them back.
       At this point, we need to check the paymentData and details</p>
       <h4 data-bind="text: apiUrlOrMethod"></h4>
       <div class="col-md-12 back-white">
         <pre data-bind="html: apiRequest"></pre>
       </div>
       <div class="col-md-12 back-white">
         <pre data-bind="html: apiResponse"></pre>
       </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiew/Repos/knockout-laravel-adyen/resources/views/redirect-page.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html id="ng-app" data-ng-app="app" xmlns:ng="http://angularjs.org" class="geolocation localstorage canvas adownload no-touchevents formvalidation srcset ng-scope">
  <head>
    <style type="text/css">
      @charset  "UTF-8";
      [ng\:cloak],
      [ng-cloak],
      [data-ng-cloak],
      [x-ng-cloak],
      .ng-cloak,
      .x-ng-cloak,
      .ng-hide:not(.ng-hide-animate) {
      display: none !important;
      }
      ng\:form {
      display: block;
      }
      .ng-animate-shim {
      visibility: hidden;
      }
      .ng-anchor {
      position: absolute;
      }
    </style>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script id="twitter-wjs" src="https://platform.twitter.com/widgets.js"></script>
    <script async="" src="https://www.greggs.co.uk//static.ads-twitter.com/uwt.js"></script>
    <script src="https://connect.facebook.net/signals/config/168209450773905?v=2.9.18&amp;r=stable" async=""></script>
    <script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script>
    <script async="" src="https://www.greggs.co.uk//www.googletagmanager.com/gtm.js?id=GTM-KSCZXG"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <title>IP Centrum Invoice Generator</title>
    <meta name="description" content="From sandwiches to pasties, pick a great deal for breakfast and lunch at your local Greggs today. Read more here at greggs.co.uk">
    <meta name="keywords" content="">
    <meta http-equiv="content-type" content="text/html; charset=utf-8 ;">
    <meta http-equiv="Content-Security-Policy" content="default-src * data:; style-src 'self' http://* 'unsafe-inline'; script-src 'self' http://* 'unsafe-inline' 'unsafe-eval'">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Facebook Pixel Code -->
    <script>
      ! function(f, b, e, v, n, t, s) {
          if (f.fbq) return;
          n = f.fbq = function() {
              n.callMethod ?
                  n.callMethod.apply(n, arguments) : n.queue.push(arguments)
          };
          if (!f._fbq) f._fbq = n;
          n.push = n;
          n.loaded = !0;
          n.version = '2.0';
          n.queue = [];
          t = b.createElement(e);
          t.async = !0;
          t.src = v;
          s = b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t, s)
      }(window, document, 'script',
          'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '168209450773905');
      fbq('track', 'PageView');
    </script>
    <noscript>
      <img height="1" width="1" src="https://www.facebook.com/tr?id=168209450773905&ev=PageView
        &noscript=1" />
    </noscript>
    <!-- End Facebook Pixel Code -->
    <!-- Twitter universal website tag code -->
    <script>
      ! function(e, t, n, s, u, a) {
          e.twq || (s = e.twq = function() {
                  s.exe ? s.exe.apply(s, arguments) : s.queue.push(arguments);
              }, s.version = '1.1', s.queue = [], u = t.createElement(n), u.async = !0, u.src = '//static.ads-twitter.com/uwt.js',
              a = t.getElementsByTagName(n)[0], a.parentNode.insertBefore(u, a))
      }(window, document, 'script');
      // Insert Twitter Pixel ID and Standard Event data below
      twq('init', 'o0yww');
      twq('track', 'PageView');
    </script>
    <!-- End Twitter universal website tag code -->
    <!-- Bing Meta -->
    <meta name="msvalidate.01" content="5DE99F8EB7E368279F5E83E1A8EC8EBC">
    <script>
      // Picture element HTML5 shiv
      document.createElement("picture");
    </script>
    <!-- FACBOOK META -->
    
    <link rel="shortcut icon" href="https://d372dbxlg0efz4.cloudfront.net/favicon.ico">
    <link rel="stylesheet" href="/css/greggs.min.css">
    <!--[if lte IE 8]>
    <script src="https://www.greggs.co.uk//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>
    <![endif]-->
  </head>
  <body ng-controller="mainCtrl" class="ng-scope">
    
    <!-- uiView:  -->
    <main class="page" autoscroll="false" ui-view="" style="padding-top: 0px;">
      
          
          
          <h1 class="text-center" style="text-align:center;">Sample Pay By Link Invoice Generator</h1>
          <section id="login" class="container col-md-8 col-md-offset-2" style="margin-top: 20px;">
            <section id="login_form_wrapper" style="margin-top: 0px;">
              <form name="loginForm" novalidate="true" data-bind="submit:sendPaymentLink">
                <div class="input_container flex" data-bind="visible: !successMessage()">
                  <div class="input_wrapper">
                    <label>Company Name</label>
                    <div class="input-holder" input-animation="">
                      <input data-bind="value: customerName" type="text" id="credentials_email" value="" ng-model="credentials.email" name="credentials_email" placeholder="Company Name" required="" class="greggs_input ng-pristine ng-invalid ng-invalid-required ng-touched" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAAXNSR0IArs4c6QAAAbNJREFUWAntV8FqwkAQnaymUkpChB7tKSfxWCie/Yb+gbdeCqGf0YsQ+hU95QNyDoWCF/HkqdeiIaEUqyZ1ArvodrOHxanQOiCzO28y781skKwFW3scPV1/febP69XqarNeNTB2KGs07U3Ttt/Ozp3bh/u7V7muheQf6ftLUWyYDB5yz1ijuPAub2QRDDunJsdGkAO55KYYjl0OUu1VXOzQZ64Tr+IiPXedGI79bQHdbheCIAD0dUY6gV6vB67rAvo6IxVgWVbFy71KBKkAFaEc2xPQarXA931ot9tyHphiPwpJgSbfe54Hw+EQHMfZ/msVEEURjMfjCjbFeG2dFxPo9/sVOSYzxmAwGIjnTDFRQLMQAjQ5pJAQkCQJ5HlekeERxHEsiE0xUUCzEO9AmqYQhiF0Oh2Yz+ewWCzEY6aYKKBZCAGYs1wuYTabKdNNMWWxnaA4gp3Yry5JBZRlWTXDvaozUgGTyQSyLAP0dbb3DtQlmcan0yngT2ekE9ARc+z4AvC7nauh9iouhpcGamJeX8XF8MaClwaeROWRA7nk+tUnyzGvZrKg0/40gdME/t8EvgG0/NOS6v9NHQAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                      <div class="indicator_bar"></div>
                    </div>
                  </div>
                  <div class="input_wrapper">
                    <label>Company Address</label>
                    <div class="input-holder" input-animation="">
                      <input data-bind="value: pickupTime" type="text" id="credentials_phone" value="" ng-model="credentials.password" name="credentials_phone" autocomplete="off" placeholder="Company Address" required="" class="greggs_input ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-pattern" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAAXNSR0IArs4c6QAAAbNJREFUWAntV8FqwkAQnaymUkpChB7tKSfxWCie/Yb+gbdeCqGf0YsQ+hU95QNyDoWCF/HkqdeiIaEUqyZ1ArvodrOHxanQOiCzO28y781skKwFW3scPV1/febP69XqarNeNTB2KGs07U3Ttt/Ozp3bh/u7V7muheQf6ftLUWyYDB5yz1ijuPAub2QRDDunJsdGkAO55KYYjl0OUu1VXOzQZ64Tr+IiPXedGI79bQHdbheCIAD0dUY6gV6vB67rAvo6IxVgWVbFy71KBKkAFaEc2xPQarXA931ot9tyHphiPwpJgSbfe54Hw+EQHMfZ/msVEEURjMfjCjbFeG2dFxPo9/sVOSYzxmAwGIjnTDFRQLMQAjQ5pJAQkCQJ5HlekeERxHEsiE0xUUCzEO9AmqYQhiF0Oh2Yz+ewWCzEY6aYKKBZCAGYs1wuYTabKdNNMWWxnaA4gp3Yry5JBZRlWTXDvaozUgGTyQSyLAP0dbb3DtQlmcan0yngT2ekE9ARc+z4AvC7nauh9iouhpcGamJeX8XF8MaClwaeROWRA7nk+tUnyzGvZrKg0/40gdME/t8EvgG0/NOS6v9NHQAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                    </div>
                  </div>
                </div>
                <div class="input_container flex" data-bind="visible: !successMessage()">
                  <div class="input_wrapper">
                    <label>Invoice #</label>
                    <div class="input-holder" input-animation="">
                      <input data-bind="value: reference" type="text" id="credentials_email" value="" ng-model="credentials.email" name="credentials_email" placeholder="Invoice #" required="" class="greggs_input ng-pristine ng-invalid ng-invalid-required ng-touched" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAAXNSR0IArs4c6QAAAbNJREFUWAntV8FqwkAQnaymUkpChB7tKSfxWCie/Yb+gbdeCqGf0YsQ+hU95QNyDoWCF/HkqdeiIaEUqyZ1ArvodrOHxanQOiCzO28y781skKwFW3scPV1/febP69XqarNeNTB2KGs07U3Ttt/Ozp3bh/u7V7muheQf6ftLUWyYDB5yz1ijuPAub2QRDDunJsdGkAO55KYYjl0OUu1VXOzQZ64Tr+IiPXedGI79bQHdbheCIAD0dUY6gV6vB67rAvo6IxVgWVbFy71KBKkAFaEc2xPQarXA931ot9tyHphiPwpJgSbfe54Hw+EQHMfZ/msVEEURjMfjCjbFeG2dFxPo9/sVOSYzxmAwGIjnTDFRQLMQAjQ5pJAQkCQJ5HlekeERxHEsiE0xUUCzEO9AmqYQhiF0Oh2Yz+ewWCzEY6aYKKBZCAGYs1wuYTabKdNNMWWxnaA4gp3Yry5JBZRlWTXDvaozUgGTyQSyLAP0dbb3DtQlmcan0yngT2ekE9ARc+z4AvC7nauh9iouhpcGamJeX8XF8MaClwaeROWRA7nk+tUnyzGvZrKg0/40gdME/t8EvgG0/NOS6v9NHQAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                      <div class="indicator_bar"></div>
                    </div>
                  </div>
                  <div class="input_wrapper">
                    <label>Invoice Amount</label>
                    <div class="input-holder" input-animation="">
                      <input data-bind="value: amount" type="text" id="credentials_phone" value="" ng-model="credentials.password" name="credentials_phone" autocomplete="off" placeholder="Amount" required="" class="greggs_input ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-pattern" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAAXNSR0IArs4c6QAAAbNJREFUWAntV8FqwkAQnaymUkpChB7tKSfxWCie/Yb+gbdeCqGf0YsQ+hU95QNyDoWCF/HkqdeiIaEUqyZ1ArvodrOHxanQOiCzO28y781skKwFW3scPV1/febP69XqarNeNTB2KGs07U3Ttt/Ozp3bh/u7V7muheQf6ftLUWyYDB5yz1ijuPAub2QRDDunJsdGkAO55KYYjl0OUu1VXOzQZ64Tr+IiPXedGI79bQHdbheCIAD0dUY6gV6vB67rAvo6IxVgWVbFy71KBKkAFaEc2xPQarXA931ot9tyHphiPwpJgSbfe54Hw+EQHMfZ/msVEEURjMfjCjbFeG2dFxPo9/sVOSYzxmAwGIjnTDFRQLMQAjQ5pJAQkCQJ5HlekeERxHEsiE0xUUCzEO9AmqYQhiF0Oh2Yz+ewWCzEY6aYKKBZCAGYs1wuYTabKdNNMWWxnaA4gp3Yry5JBZRlWTXDvaozUgGTyQSyLAP0dbb3DtQlmcan0yngT2ekE9ARc+z4AvC7nauh9iouhpcGamJeX8XF8MaClwaeROWRA7nk+tUnyzGvZrKg0/40gdME/t8EvgG0/NOS6v9NHQAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                    </div>
                  </div>
                </div>
                <!-- /Disabling Chrome Autofill -->
                <div class="input_container flex" data-bind="visible: !successMessage()">
                  <div class="input_wrapper">
                    <label>Company Email</label>
                    <div class="input-holder" input-animation="">
                      <input data-bind="value: shopperEmail" type="text" id="credentials_email" value="" ng-model="credentials.email" name="credentials_email" placeholder="Email" required="" class="greggs_input ng-pristine ng-invalid ng-invalid-required ng-touched" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAAXNSR0IArs4c6QAAAbNJREFUWAntV8FqwkAQnaymUkpChB7tKSfxWCie/Yb+gbdeCqGf0YsQ+hU95QNyDoWCF/HkqdeiIaEUqyZ1ArvodrOHxanQOiCzO28y781skKwFW3scPV1/febP69XqarNeNTB2KGs07U3Ttt/Ozp3bh/u7V7muheQf6ftLUWyYDB5yz1ijuPAub2QRDDunJsdGkAO55KYYjl0OUu1VXOzQZ64Tr+IiPXedGI79bQHdbheCIAD0dUY6gV6vB67rAvo6IxVgWVbFy71KBKkAFaEc2xPQarXA931ot9tyHphiPwpJgSbfe54Hw+EQHMfZ/msVEEURjMfjCjbFeG2dFxPo9/sVOSYzxmAwGIjnTDFRQLMQAjQ5pJAQkCQJ5HlekeERxHEsiE0xUUCzEO9AmqYQhiF0Oh2Yz+ewWCzEY6aYKKBZCAGYs1wuYTabKdNNMWWxnaA4gp3Yry5JBZRlWTXDvaozUgGTyQSyLAP0dbb3DtQlmcan0yngT2ekE9ARc+z4AvC7nauh9iouhpcGamJeX8XF8MaClwaeROWRA7nk+tUnyzGvZrKg0/40gdME/t8EvgG0/NOS6v9NHQAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                      <div class="indicator_bar"></div>
                    </div>
                  </div>
                  <div class="input_wrapper">
                    <label>Company Phone</label>
                    <div class="input-holder" input-animation="">
                      <input data-bind="value: phoneNumber" type="text" id="credentials_phone" value="" ng-model="credentials.password" name="credentials_phone" autocomplete="off" placeholder="Phone #" required="" class="greggs_input ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-pattern" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAAXNSR0IArs4c6QAAAbNJREFUWAntV8FqwkAQnaymUkpChB7tKSfxWCie/Yb+gbdeCqGf0YsQ+hU95QNyDoWCF/HkqdeiIaEUqyZ1ArvodrOHxanQOiCzO28y781skKwFW3scPV1/febP69XqarNeNTB2KGs07U3Ttt/Ozp3bh/u7V7muheQf6ftLUWyYDB5yz1ijuPAub2QRDDunJsdGkAO55KYYjl0OUu1VXOzQZ64Tr+IiPXedGI79bQHdbheCIAD0dUY6gV6vB67rAvo6IxVgWVbFy71KBKkAFaEc2xPQarXA931ot9tyHphiPwpJgSbfe54Hw+EQHMfZ/msVEEURjMfjCjbFeG2dFxPo9/sVOSYzxmAwGIjnTDFRQLMQAjQ5pJAQkCQJ5HlekeERxHEsiE0xUUCzEO9AmqYQhiF0Oh2Yz+ewWCzEY6aYKKBZCAGYs1wuYTabKdNNMWWxnaA4gp3Yry5JBZRlWTXDvaozUgGTyQSyLAP0dbb3DtQlmcan0yngT2ekE9ARc+z4AvC7nauh9iouhpcGamJeX8XF8MaClwaeROWRA7nk+tUnyzGvZrKg0/40gdME/t8EvgG0/NOS6v9NHQAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                    </div>
                  </div>
                </div>
                <div class="flex col-md-12" style="color:green; font-weight: bold; margin-bottom: 15px;">
                  <p>As much data as is required to generate an IP Centrum invoice, with necessary Adyen Pay By Link data passed onto the Adyen endpoint for URL generation</p>
                </div>
                <div class="flex col-md-12" style="color:green; font-weight: bold; margin-bottom: 15px;" data-bind="html: successMessage, visible: successMessage()"></div>
                <div class="flex col-md-12 alert-danger" style="color:red; font-weight: bold;" data-bind="text: errorMessage, visible: errorMessage()"></div>
                <div class="submit_container" data-bind="visible: !successMessage()">
                  <button type="submit" id="login_submit" class="submit_button main_button yellow">Submit Invoice</button>
                </div>
              </form>
            </section>
          </section>
          
        </section>
      </section>
      
    </main>
    <div id="shadow_blocker"></div>
    <!--<script src="https://www.greggs.co.uk/res/js/greggs.min.js"></script>-->
    <!-- <script src="https://www.google.com/recaptcha/api.js?onload=vcRecaptchaApiLoaded&render=explicit" async defer></script> -->
    <script async="" type="text/javascript" src="https://www.greggs.co.uk/_Incapsula_Resource?SWJIYLWA=719d34d31c8e3a6e6fffd425f7e032f3&amp;ns=1&amp;cb=1631109170"></script>
    <iframe height="0" width="0" style="display: none; visibility: hidden;" src="https://www.greggs.co.uk//1697160.fls.doubleclick.net/activityi;src=1697160;type=conte749;cat=000un0;ord=1838265232339;gtm=2wg4m0;auiddc=924628239.1588328857;u3=https%3A%2F%2Fwww.greggs.co.uk%2F;u5=Desktop;~oref=https%3A%2F%2Fwww.greggs.co.uk%2F?"></iframe>
    <div id="ngProgress-container" class="ng-scope">
      <div id="ngProgress" style="height: 2px; background-color: firebrick; color: firebrick; width: 0%; opacity: 1;"></div>
    </div>
    <script type="text/javascript" id="" src="https://secure.adnxs.com/px?id=1168649&amp;seg=19410407&amp;t=1"></script>
    <script type="text/javascript" id="" src="https://secure.adnxs.com/px?id=1168867&amp;t=1"></script>
    <noscript><img height="1" width="1" src="https://www.facebook.com/tr?id=168209450773905&amp;ev=PageView&amp;noscript=1">
    </noscript>
    <iframe scrolling="no" frameborder="0" allowtransparency="true" src="https://platform.twitter.com/widgets/widget_iframe.c63890edc4243ee77048d507b181eeec.html?origin=https%3A%2F%2Fwww.greggs.co.uk" title="Twitter settings iframe" style="display: none;"></iframe>
    <script src="https://analytics.twitter.com/i/adsct?p_id=Twitter&amp;p_user_id=0&amp;txn_id=o0yww&amp;events=%5B%5B%22pageview%22%2Cnull%5D%5D&amp;tw_sale_amount=0&amp;tw_order_quantity=0&amp;tw_iframe_status=0&amp;tpx_cb=twttr.conversion.loadPixels&amp;tw_document_href=https%3A%2F%2Fwww.greggs.co.uk%2F" type="text/javascript"></script>
    <!-- ADYEN -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/knockout/3.5.0/knockout-min.js"></script>
    <script src="/js/knockout/greggs.js"></script>
  </body>
</html>
<?php /**PATH /Users/jamiew/Repos/knockout-laravel-adyen/resources/views/greggs.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
  <div class="row see-through mild-opacity mt-3">
    <div class="col-md-6 offset-md-3">
      <h3 class="text-center">POS Terminal API</h3>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiew/Repos/knockout-laravel-adyen/resources/views/pos-terminal-api.blade.php ENDPATH**/ ?>
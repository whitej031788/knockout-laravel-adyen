import { ApplePayService } from './partials/apple-pay-service.js';

function getDecimalAmount(amount, currencyCode) {
    return parseInt(String(amount), 10) / 100;
};

function formatAmount(amount, currencyCode) {
  return String(getDecimalAmount(amount, currencyCode));
}

function preparePaymentRequest() {
  const formattedAmount = formatAmount(100, "GBP");

  return {
      countryCode: "GB",
      currencyCode: "GBP",
      total: {
          label: "Jamie Test Merchant",
          amount: "1.00",
          type: "final"
      },
      //lineItems: props.lineItems,
      //shippingMethods: props.shippingMethods,
      //shippingType: props.shippingType,
      merchantCapabilities: ["supports3DS"],
      //supportedCountries: props.supportedCountries,
      supportedNetworks: [
        "visa",
        "masterCard",
        "amex",
        "discover"
      ],
      //requiredShippingContactFields: props.requiredShippingContactFields,
      //requiredBillingContactFields: props.requiredBillingContactFields,
      //billingContact: props.billingContact,
      //shippingContact: props.shippingContact,
      //applicationData: props.applicationData
  };
}

function testAwait(validationURL) {
  return fetch('/api/adyen/applePaySession', {
    method: 'POST', // or 'PUT'
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({"sessionUrl" : validationURL}),
  })
  .then(response => response.json());
}

async function myOnValidateMerchant (resolve, reject, validationURL) {
  let response = await testAwait(validationURL);
  resolve(response);
}

function myOnPaymentAuthorized(resolve, reject, event) {
  console.log(event);
  resolve(event);
}

const session = new ApplePayService(preparePaymentRequest(), {
    version: 3,
    onValidateMerchant: myOnValidateMerchant,
    onCancel: event => console.log(event),
    //onPaymentMethodSelected,
    //onShippingMethodSelected,
    //onShippingContactSelected,
    onPaymentAuthorized: myOnPaymentAuthorized
});

window.session = session;

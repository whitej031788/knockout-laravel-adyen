function knockoutObj() {
  this.jsonPrettyHighlightToId = function(jsonobj) {
    var json = JSON.stringify(jsonobj, undefined, 2);

    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    json = json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
      var cls = 'color: darkorange;';
      if (/^"/.test(match)) {
        if (/:$/.test(match)) {
          cls = 'color: red;';
        } else {
          cls = 'color: green;';
        }
      } else if (/true|false/.test(match)) {
        cls = 'color: blue;';
      } else if (/null/.test(match)) {
        cls = 'color: magenta;';
      }
      return '<span style="' + cls + '">' + match + '</span>';
    });

    return json;
  }
  
  this.payReqObj = bladeJsonObj;
  this.apiUrlOrMethod = ko.observable(this.payReqObj.method);
  this.apiRequest = ko.observable(this.jsonPrettyHighlightToId(this.payReqObj.request));
  this.apiResponse = ko.observable(this.jsonPrettyHighlightToId(this.payReqObj.response));
}

ko.applyBindings(new knockoutObj());

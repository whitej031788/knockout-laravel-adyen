
<?php
    /*
     This PHP code provides a payment form for the Adyen Hosted Payment Pages
     */

    /*
     account details
     $skinCode:        the skin to be used
     $merchantAccount: the merchant account we want to process this payment with.
     $sharedSecret:    the shared HMAC key.
     */

    $skinCode        = "7yAdzVZo"; // your skinCode
    $merchantAccount = "LukeStrudwickCOM"; // your merchantAccount
    $hmacKey         = "53FFCDAD2BD911F98C2B3F6C533E240912EAF17B9E88B273026D45384FBB2B73"; // your Hmac Key

    /*
     KLARNA HPP
     */

     $params = array(
        "merchantReference" => "Klarna15",

        "merchantAccount"   =>  $merchantAccount,
        "currencyCode"      => "GBP",
        "paymentAmount"     => "5600",
        "sessionValidity"   => "2020-12-25T10:31:06Z",
        "shipBeforeDate"    => "2020-07-01",
        "shopperLocale"     => "en_GB",
        "skinCode"          => $skinCode,
        "brandCode"         => "",
        "shopperEmail"      => "test@adyen.com",
        "shopperReference"  => "123",

        "recurringContract" => "ONECLICK",
        "shopperEmail"      => "luke.strudwick@adyen.com",
        "shopperReference"  => "luke1232245",
        "shopperCountry"  => "GB",
        "shopper.firstName"  => "Luke",
        "shopper.lastName"  => "Strudwick",
        "shopper.gender"  => "MALE",
        "shopper.dateOfBirthDayOfMonth" => "25",
        "shopper.dateOfBirthYear" => "1987",
        "shopper.dateOfBirthMonth" => "02",
        "shopper.telephoneNumber" => "07920032684",
        "countryCode"  => "GB",
        "openinvoicedata.numberOfLines" => "2",
        //"openinvoicedata.refundDescription" => "Refund for testReference",
        "openinvoicedata.line1.numberOfItems" => "1" ,
      //  "openinvoicedata.line1.itemId" => "ID1",
        "openinvoicedata.line1.itemAmount" => "3500" ,
        "openinvoicedata.line1.currencyCode" => "GBP" ,
        "openinvoicedata.line1.itemVatAmount" => "350" ,
        "openinvoicedata.line1.itemVatPercentage" => "1000",
        "openinvoicedata.line1.vatCategory" => "High",
        "openinvoicedata.line1.description" => "Description 1",

        "openinvoicedata.line2.numberOfItems" => "1",
        "openinvoicedata.line2.itemAmount" => "2100",
    //    "openinvoicedata.line2.itemId" => "ID2",
        "openinvoicedata.line2.currencyCode" => "GBP",
        "openinvoicedata.line2.itemVatAmount" => "210",
        "openinvoicedata.line2.itemVatPercentage" => "1000",
        "openinvoicedata.line2.vatCategory" => "Low",
        "openinvoicedata.line2.description" => "Description 2",
        "openinvoicedata.merchantData" => "d2hhdGV2ZXIga2xhcm5hIHJlcXVlc3RzIGZvciBFTUQgY2FuIGJlIHB1dCBoZXJlLg==",

        "billingAddress.street" => "Hills Place",
        "billingAddress.houseNumberOrName" => "10",
        "billingAddress.city" => "London",
        "billingAddress.postalCode" => "W1F7SD",
        "billingAddress.stateOrProvince" => "",
        "billingAddress.country" => "GB",
        "billingAddressType" => "",

        "deliveryAddress.street" => "Berrys Lane",
        "deliveryAddress.houseNumberOrName" => "2",
        "deliveryAddress.city" => "Byfleet",
        "deliveryAddress.postalCode" => "KT147AU",
        "deliveryAddress.stateOrProvince" => "",
        "deliveryAddress.country" => "GB",
        "deliveryAddressType" => "",

        "merchantReturnData"=> "http://localhost:8000/Nextcloud/Documents/Example%20Integrations/results.php",
    );

    /*
     process fields
     */

    // The character escape function
     $escapeval = function($val) {
        return str_replace(':','\\:',str_replace('\\','\\\\',$val));
    };

    // Sort the array by key using SORT_STRING order
    ksort($params, SORT_STRING);

    // Generate the signing data string
    $signData = implode(":",array_map($escapeval,array_merge(array_keys($params), array_values($params))));

    // base64-encode the binary result of the HMAC computation
    $merchantSig = base64_encode(hash_hmac('sha256',$signData,pack("H*" , $hmacKey),true));
    $params["merchantSig"] = $merchantSig;

?>

<!-- Complete submission form -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <title>Adyen Payment</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
    <form name="adyenForm" action="https://test.adyen.com/hpp/pay.shtml" method="post">

        <?php
        foreach ($params as $key => $value){
            echo '        <input type="hidden" name="' .htmlspecialchars($key,   ENT_COMPAT | ENT_HTML401 ,'UTF-8').
            '" value="' .htmlspecialchars($value, ENT_COMPAT | ENT_HTML401 ,'UTF-8') . '" />' ."\n" ;
        }
        ?>
        <input type="submit" value="Submit" />
    </form>
</body>
</html>
